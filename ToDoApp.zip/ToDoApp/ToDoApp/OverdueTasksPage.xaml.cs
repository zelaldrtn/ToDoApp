using System.Collections.ObjectModel;
using ToDoApp.Hizmet;
using ToDoApp.Model;

namespace ToDoApp
{
    public partial class OverdueTasksPage : ContentPage
    {
        private readonly ToDoDatabase _database;
        private readonly IServiceProvider _serviceProvider;

        public ObservableCollection<TodoItem> OverdueTasks { get; } = new();

        public OverdueTasksPage(ToDoDatabase database, IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _database = database;
            _serviceProvider = serviceProvider;
            TasksCollection.ItemsSource = OverdueTasks;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await LoadDataAsync();
        }

        private async Task LoadDataAsync()
        {
            // Fetch items asynchronously on a background thread to prevent UI lockups
            var items = await Task.Run(async () => await _database.GetItemsAsync());
            var overdueItems = items.Where(x => !x.IsCompleted && x.DueDate.Date < DateTime.Today).ToList();

            // Populate the ObservableCollection on the UI thread without re-assigning ItemsSource
            OverdueTasks.Clear();
            foreach (var item in overdueItems)
            {
                OverdueTasks.Add(item);
            }
        }

        async void OnTaskCompletedChanged(object sender, CheckedChangedEventArgs e)
        {
            if (sender is CheckBox checkBox && checkBox.BindingContext is TodoItem item)
            {
                if (item.IsCompleted != e.Value)
                {
                    item.IsCompleted = e.Value;
                    await _database.SaveItemAsync(item);
                    
                    // Directly remove from the UI collection if it becomes completed
                    if (item.IsCompleted)
                    {
                        OverdueTasks.Remove(item);
                    }
                }
            }
        }

        async void OnEditInvoked(object sender, EventArgs e)
        {
            var item = (sender as SwipeItem)?.CommandParameter as TodoItem;
            if (item == null) return;

            var editPage = _serviceProvider.GetService<TaskEditPage>();
            if (editPage != null)
            {
                editPage.SetItem(item);
                await Navigation.PushAsync(editPage);
            }
        }

        async void OnDeleteInvoked(object sender, EventArgs e)
        {
            var swipeItem = sender as SwipeItem;
            var item = swipeItem?.CommandParameter as TodoItem;

            if (item == null)
            {
                await Shell.Current.DisplayAlert("Sil", "Emin misiniz?", "Evet", "Hayır");
                return;
            }

            bool confirm = await Shell.Current.DisplayAlert("Sil", $"'{item.Title}' görevini silmek istediğinize emin misiniz?", "Evet", "Hayır");

            if (confirm)
            {
                await _database.DeleteItemAsync(item);
                // Directly remove from the UI collection to avoid full reload
                OverdueTasks.Remove(item);
            }
        }
    }
}
