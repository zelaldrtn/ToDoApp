using ToDoApp.Hizmet;
using ToDoApp.Model;
namespace ToDoApp
{
    public partial class AppShell : Shell
    {
        //komutu tanımlıyoruz
        public Command AddNewTaskCommand { get; }
        public Command GoToCompletedCommand { get; }
        public Command GoToOverDueCommand { get; }
        public Command GoToDashboardCommand { get; }
        public AppShell()
        {
            InitializeComponent();

            //rotaları manuel kaydederek DI desteğini sağla
            Routing.RegisterRoute(nameof(TaskEditPage), typeof(TaskEditPage));
            Routing.RegisterRoute(nameof(CompletedTasksPage), typeof(CompletedTasksPage));
            Routing.RegisterRoute(nameof(OverdueTasksPage), typeof(OverdueTasksPage));
            Routing.RegisterRoute(nameof(DashboardPage), typeof(DashboardPage));

            //komutun ne yapacağını belirliyoruz
            AddNewTaskCommand = new Command(async () => await OnAddNewTask());
            GoToCompletedCommand = new Command(async () => await GoToPage(nameof(CompletedTasksPage)));
            GoToOverDueCommand = new Command(async () => await GoToPage(nameof(OverdueTasksPage)));
            GoToDashboardCommand = new Command(async () => await GoToPage(nameof(DashboardPage)));

            //xaml tarafının bu komutu görebilmesi için BindingContext i kendisi yapıyoruz
            BindingContext = this;
        }

        private async Task OnAddNewTask()
        {
            //sayfayı servis sağlayıcı üzerinden güvenli bir şekilde alıyoruz
            //app.current üzerinden servis sağlayıcıya erişebiliriz
            var services = Handler?.MauiContext?.Services;
            var editPage = services?.GetService<TaskEditPage>();

            if (editPage != null)
            {
                editPage.SetItem(new TodoItem { DueDate = DateTime.Now });
                await Navigation.PushAsync(editPage);

                //menüyü (flyout) otomatik kapat
                FlyoutIsPresented = false;
            }
        }

        private async Task GoToPage(string route)
        {
            await Shell.Current.GoToAsync(route);
            FlyoutIsPresented = false;
        }
    }
}
