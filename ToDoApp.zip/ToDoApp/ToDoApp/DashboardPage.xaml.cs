using ToDoApp.Hizmet;
using ToDoApp.Model;

namespace ToDoApp;

public partial class DashboardPage : ContentPage
{
    private readonly ToDoDatabase _database;

    public DashboardPage(ToDoDatabase database)
    {
        InitializeComponent();
        _database = database;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await LoadStatsAsync();
    }

    private async Task LoadStatsAsync()
    {
        var items = await _database.GetItemsAsync();
        
        int total = items.Count;
        int completed = items.Count(x => x.IsCompleted);
        int overdue = items.Count(x => !x.IsCompleted && x.DueDate.Date < DateTime.Today);
        int pending = items.Count(x => !x.IsCompleted && x.DueDate.Date >= DateTime.Today);

        CompletedLabel.Text = completed.ToString();
        PendingLabel.Text = pending.ToString();
        OverdueLabel.Text = overdue.ToString();

        double efficiency = total == 0 ? 100.0 : ((double)completed / total) * 100.0;
        int score = (int)Math.Round(efficiency);

        // Update Progress Bar
        double completedRatio = total == 0 ? 1.0 : (double)completed / total;
        double remainingRatio = 1.0 - completedRatio;

        if (completedRatio == 0)
        {
            ProgressBarGrid.ColumnDefinitions[0] = new ColumnDefinition { Width = new GridLength(0) };
            ProgressBarGrid.ColumnDefinitions[1] = new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) };
        }
        else if (completedRatio == 1)
        {
            ProgressBarGrid.ColumnDefinitions[0] = new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) };
            ProgressBarGrid.ColumnDefinitions[1] = new ColumnDefinition { Width = new GridLength(0) };
        }
        else
        {
            ProgressBarGrid.ColumnDefinitions[0] = new ColumnDefinition { Width = new GridLength(completedRatio, GridUnitType.Star) };
            ProgressBarGrid.ColumnDefinitions[1] = new ColumnDefinition { Width = new GridLength(remainingRatio, GridUnitType.Star) };
        }

        // Set Corporate Statistics Messages
        if (total == 0)
        {
            EfficiencyText.Text = "Kayıtlı Görev Bulunmuyor";
            SubEfficiencyText.Text = "Sistemde analiz edilecek aktif veya tamamlanmış herhangi bir görev kaydı mevcut değil.";
        }
        else if (score == 0)
        {
            EfficiencyText.Text = "Tamamlanma Oranı: %0";
            SubEfficiencyText.Text = "Kayıtlı tüm görevleriniz bekleme aşamasındadır. Performansınızı artırmak için işlerinizi tamamlayın.";
        }
        else if (score > 0 && score < 40)
        {
            EfficiencyText.Text = $"Tamamlanma Oranı: %{score}";
            SubEfficiencyText.Text = "Başlangıç aşamasındasınız. Bekleyen iş yükünü azaltmak için görevlerinizi tamamlamaya devam edin.";
        }
        else if (score >= 40 && score < 75)
        {
            EfficiencyText.Text = $"Tamamlanma Oranı: %{score}";
            SubEfficiencyText.Text = "Orta düzey verimlilik sağlandı. İş yükünüzün yarısına yakını veya fazlası tamamlanmıştır.";
        }
        else if (score >= 75 && score < 100)
        {
            EfficiencyText.Text = $"Tamamlanma Oranı: %{score}";
            SubEfficiencyText.Text = "Yüksek verimlilik oranına ulaşıldı. Kalan az sayıdaki görevi tamamlayarak süreci bitirebilirsiniz.";
        }
        else // 100%
        {
            EfficiencyText.Text = "Tamamlanma Oranı: %100";
            SubEfficiencyText.Text = "Tebrikler! Kayıtlı tüm görevleriniz başarıyla sonuçlandırılmış ve iş yükü tamamen eritilmiştir.";
        }
    }
}
