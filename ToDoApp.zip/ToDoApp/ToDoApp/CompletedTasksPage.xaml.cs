using System.Collections.ObjectModel;
using ToDoApp.Hizmet;
using ToDoApp.Model;

namespace ToDoApp
{
    public partial class CompletedTasksPage : ContentPage
    {
        private readonly ToDoDatabase _database;
        private readonly IServiceProvider _serviceProvider;

        public ObservableCollection<TodoItem> CompletedTasks { get; } = new();

        public CompletedTasksPage(ToDoDatabase database, IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _database = database;
            _serviceProvider = serviceProvider;
            TasksCollection.ItemsSource = CompletedTasks;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await LoadDataAsync();
        }

        private async Task LoadDataAsync()
        {
            // Fetch items asynchronously on a background thread to prevent UI lockups
            var items = await Task.Run(async () => await _database.GetItemsAsync());
            var completedItems = items.Where(x => x.IsCompleted).ToList();

            // Populate the ObservableCollection on the UI thread without re-assigning ItemsSource
            CompletedTasks.Clear();
            foreach (var item in completedItems)
            {
                CompletedTasks.Add(item);
            }
        }

        async void OnTaskCompletedChanged(object sender, CheckedChangedEventArgs e)
        {
            if (sender is CheckBox checkBox && checkBox.BindingContext is TodoItem item)
            {
                if (item.IsCompleted != e.Value)
                {
                    item.IsCompleted = e.Value;
                    await _database.SaveItemAsync(item);
                    
                    // Directly remove from the UI collection if it becomes uncompleted
                    if (!item.IsCompleted)
                    {
                        CompletedTasks.Remove(item);
                    }
                }
            }
        }

        async void OnEditInvoked(object sender, EventArgs e)
        {
            var item = (sender as SwipeItem)?.CommandParameter as TodoItem;
            if (item == null) return;

            var editPage = _serviceProvider.GetService<TaskEditPage>();
            if (editPage != null)
            {
                editPage.SetItem(item);
                await Navigation.PushAsync(editPage);
            }
        }

        async void OnDeleteInvoked(object sender, EventArgs e)
        {
            var swipeItem = sender as SwipeItem;
            var item = swipeItem?.CommandParameter as TodoItem;

            if (item == null)
            {
                await Shell.Current.DisplayAlert("Sil", "Emin misiniz?", "Evet", "Hayır");
                return;
            }

            bool confirm = await Shell.Current.DisplayAlert("Sil", $"'{item.Title}' görevini silmek istediğinize emin misiniz?", "Evet", "Hayır");

            if (confirm)
            {
                await _database.DeleteItemAsync(item);
                // Directly remove from the UI collection to avoid full reload
                CompletedTasks.Remove(item);
            }
        }
    }
}
