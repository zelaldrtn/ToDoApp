using SQLite;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ToDoApp.Model
{
    public class TodoItem : INotifyPropertyChanged
    {
        private bool _isCompleted;

        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Category { get; set; }
        public DateTime DueDate { get; set; }
        
        public bool IsCompleted 
        { 
            get => _isCompleted; 
            set 
            {
                if (_isCompleted != value)
                {
                    _isCompleted = value;
                    OnPropertyChanged();
                }
            }
        }

        private double _uiResultOpacity = 1.0;
        private double _uiResultScale = 1.0;
        private double _uiResultTranslationX = 0.0;

        [Ignore]
        public double UIResultOpacity
        {
            get => _uiResultOpacity;
            set
            {
                if (_uiResultOpacity != value)
                {
                    _uiResultOpacity = value;
                    OnPropertyChanged();
                }
            }
        }

        [Ignore]
        public double UIResultScale
        {
            get => _uiResultScale;
            set
            {
                if (_uiResultScale != value)
                {
                    _uiResultScale = value;
                    OnPropertyChanged();
                }
            }
        }

        [Ignore]
        public double UIResultTranslationX
        {
            get => _uiResultTranslationX;
            set
            {
                if (_uiResultTranslationX != value)
                {
                    _uiResultTranslationX = value;
                    OnPropertyChanged();
                }
            }
        }

        [Ignore]
        public bool IsOverdue => !IsCompleted && DueDate.Date < DateTime.Today;

        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null!)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
