using Microsoft.Extensions.Logging;
using ToDoApp.Hizmet;

namespace ToDoApp
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });
            //veritabanı servisini kaydet (singleton: uygulama boyunca tek bir kopya)
            builder.Services.AddSingleton<ToDoDatabase>();

            //Sayfaları kaydet (transient: her çağırıldığında yeni bir kopya)
            builder.Services.AddTransient<MainPage>();
            builder.Services.AddTransient<TaskEditPage>();
            builder.Services.AddTransient<CompletedTasksPage>();
            builder.Services.AddTransient<OverdueTasksPage>();
            builder.Services.AddTransient<DashboardPage>();

#if DEBUG
    		builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
