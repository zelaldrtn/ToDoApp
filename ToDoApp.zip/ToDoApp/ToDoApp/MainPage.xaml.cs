using System.Collections.ObjectModel;
using System.ComponentModel;
using ToDoApp.Hizmet;
using ToDoApp.Model;

namespace ToDoApp
{
    public class DateModel : INotifyPropertyChanged
    {
        public DateTime Date { get; set; }
        public string DisplayText => Date.ToString("dd MMMM");

        private bool _allCompleted;
        public bool AllCompleted
        {
            get => _allCompleted;
            set
            {
                if (_allCompleted != value)
                {
                    _allCompleted = value;
                    OnPropertyChanged(nameof(AllCompleted));
                }
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public partial class MainPage : ContentPage
    {
        private readonly ToDoDatabase _database;
        private readonly IServiceProvider _serviceProvider;
        private DateTime _selectedDate = DateTime.Today;

        private List<TodoItem> _allTasksForDate = new();
        private string _selectedCategory = "Tümü";
        private string _searchText = "";

        public MainPage(ToDoDatabase database, IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _database = database;
            _serviceProvider = serviceProvider;
            LoadDates();
        }

        private void LoadDates()
        {
            var dates = new ObservableCollection<DateModel>();
            // Generate dates starting from today
            for (int i = 0; i <= 14; i++)
            {
                dates.Add(new DateModel { Date = DateTime.Today.AddDays(i) });
            }
            DatesCollection.ItemsSource = dates;
            
            // Select today by default
            var todayModel = dates.FirstOrDefault(d => d.Date == DateTime.Today);
            if (todayModel != null)
            {
                DatesCollection.SelectedItem = todayModel;
            }
        }

        void OnDateSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.CurrentSelection.FirstOrDefault() is DateModel selected)
            {
                _selectedDate = selected.Date;
                _ = LoadTasksForDate(_selectedDate);
            }
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            await LoadTasksForDate(_selectedDate);
            _ = CheckOverdueTasksAsync();
        }

        private static bool _hasCheckedOverdueThisSession = false;
        private async Task CheckOverdueTasksAsync()
        {
            if (_hasCheckedOverdueThisSession) return;
            _hasCheckedOverdueThisSession = true;

            var allItems = await _database.GetItemsAsync();
            var overdueCount = allItems.Count(x => !x.IsCompleted && x.DueDate.Date < DateTime.Today);
            if (overdueCount > 0)
            {
                MainThread.BeginInvokeOnMainThread(async () =>
                {
                    await DisplayAlert("Gecikmiş Görev Bildirimi", 
                        $"Süresi geçmiş {overdueCount} adet göreviniz bulunmaktadır. Lütfen bu görevleri gözden geçiriniz.", 
                        "Tamam");
                });
            }
        }

        private async Task UpdateDatesCompletionStatus()
        {
            var allItems = await _database.GetItemsAsync();
            var dates = DatesCollection.ItemsSource as ObservableCollection<DateModel>;
            if (dates == null) return;

            foreach (var dateModel in dates)
            {
                var tasksForDate = allItems.Where(x => x.DueDate.Date == dateModel.Date.Date).ToList();
                if (tasksForDate.Any() && tasksForDate.All(x => x.IsCompleted))
                {
                    dateModel.AllCompleted = true;
                }
                else
                {
                    dateModel.AllCompleted = false;
                }
            }
        }

        private async Task LoadTasksForDate(DateTime date)
        {
            var allItems = await _database.GetItemsAsync();
            // Filter tasks by the selected date
            _allTasksForDate = allItems.Where(x => x.DueDate.Date == date.Date).ToList();
            await ApplyFilters(animate: false);
            await UpdateDatesCompletionStatus();
        }

        private async Task ApplyFilters(bool animate)
        {
            var filtered = _allTasksForDate.Where(x => 
                (_selectedCategory == "Tümü" || x.Category == _selectedCategory) &&
                (string.IsNullOrWhiteSpace(_searchText) || (x.Title != null && x.Title.Contains(_searchText, StringComparison.OrdinalIgnoreCase)))
            ).ToList();

            if (animate && TasksCollection.ItemsSource is List<TodoItem> currentList && currentList.Any())
            {
                // Find items that should be removed from view
                var itemsToFadeOut = currentList.Where(x => !filtered.Contains(x)).ToList();

                if (itemsToFadeOut.Any())
                {
                    int steps = 10;
                    for (int i = 1; i <= steps; i++)
                    {
                        double progress = (double)i / steps;
                        foreach (var item in itemsToFadeOut)
                        {
                            item.UIResultOpacity = 1.0 - progress;
                            item.UIResultScale = 1.0 - (progress * 0.15);
                            item.UIResultTranslationX = progress * 40.0;
                        }
                        await Task.Delay(16); // ~60fps
                    }
                }
            }

            // Reset UI properties of filtered elements
            foreach (var item in filtered)
            {
                item.UIResultOpacity = 1.0;
                item.UIResultScale = 1.0;
                item.UIResultTranslationX = 0.0;
            }

            TasksCollection.ItemsSource = filtered;
        }

        private void OnSearchFocused(object sender, FocusEventArgs e)
        {
            SearchBorder.Animate("ExpandSearch", new Animation(v => SearchBorder.WidthRequest = v, 280, 340), length: 220, easing: Easing.CubicOut);
            SearchBorder.Stroke = new SolidColorBrush(Color.FromArgb("#1A73E8"));
            SearchBorder.StrokeThickness = 1.5;
        }

        private void OnSearchUnfocused(object sender, FocusEventArgs e)
        {
            SearchBorder.Animate("CollapseSearch", new Animation(v => SearchBorder.WidthRequest = v, SearchBorder.WidthRequest, 280), length: 220, easing: Easing.CubicOut);
            SearchBorder.Stroke = new SolidColorBrush(Color.FromArgb("#60FFFFFF"));
            SearchBorder.StrokeThickness = 1;
        }

        private async void OnSearchTextChanged(object sender, TextChangedEventArgs e)
        {
            _searchText = e.NewTextValue ?? "";
            ClearSearchButton.IsVisible = !string.IsNullOrEmpty(_searchText);
            await ApplyFilters(animate: true);
        }

        private void OnClearSearchClicked(object sender, EventArgs e)
        {
            SearchEntry.Text = string.Empty;
            SearchEntry.Unfocus();
        }

        // Category Selection Handler
        private async void OnCategoryFilterClicked(object sender, EventArgs e)
        {
            if (sender is Button clickedButton)
            {
                var category = clickedButton.CommandParameter as string ?? "Tümü";
                if (_selectedCategory == category) return;

                _selectedCategory = category;

                // Reset all category buttons to default styling
                CatAllBtn.Style = (Style)Application.Current!.Resources["CategoryFilterButtonStyle"];
                CatWorkBtn.Style = (Style)Application.Current!.Resources["CategoryFilterButtonStyle"];
                CatPersonalBtn.Style = (Style)Application.Current!.Resources["CategoryFilterButtonStyle"];
                CatSchoolBtn.Style = (Style)Application.Current!.Resources["CategoryFilterButtonStyle"];
                CatShopBtn.Style = (Style)Application.Current!.Resources["CategoryFilterButtonStyle"];
                CatOtherBtn.Style = (Style)Application.Current!.Resources["CategoryFilterButtonStyle"];

                // Set clicked button to selected styling
                clickedButton.Style = (Style)Application.Current!.Resources["CategoryFilterButtonSelected"];

                await ApplyFilters(animate: true);
            }
        }

        async void OnTaskCompletedChanged(object sender, CheckedChangedEventArgs e)
        {
            if (sender is CheckBox checkBox && checkBox.BindingContext is TodoItem item)
            {
                item.IsCompleted = e.Value;
                await _database.SaveItemAsync(item);
                await UpdateDatesCompletionStatus();
            }
        }

        //yeni görev ekleme butonu veya sol menüden tetikleme
        async void OnAddNewTaskClicked(object sender, EventArgs e)
        {
            var editPage = _serviceProvider.GetService<TaskEditPage>();

            if (editPage != null)
            {
                editPage.SetItem(new TodoItem { DueDate = _selectedDate });
                await Navigation.PushAsync(editPage);
            }
        }

        //kaydırınca düzenle
        async void OnEditInvoked(object sender, EventArgs e)
        {
            var item = (sender as SwipeItem)?.CommandParameter as TodoItem;

            if (item == null) return;

            var editPage = _serviceProvider.GetService<TaskEditPage>();

            if (editPage != null)
            {
                editPage.SetItem(item);
                await Navigation.PushAsync(editPage);
            }
        }

        [Obsolete]
        async void OnDeleteInvoked(object sender, EventArgs e)
        {
            bool confirm = false;
            var swipeItem = sender as SwipeItem;
            var item = swipeItem?.CommandParameter as TodoItem;

            if (item == null)
            {
                confirm = await Shell.Current.DisplayAlert("Sil", "Emin misiniz?", "Evet", "Hayır");
                return;
            }

            confirm = await Shell.Current.DisplayAlert("Sil", $"'{item.Title}' görevini silmek istediğinize emin misiniz?", "Evet", "Hayır");

            if (confirm)
            {
                await _database.DeleteItemAsync(item);
                await LoadTasksForDate(_selectedDate);
            }
        }
    }
}
